"""Build the #41 report only after every required final record exists and passes."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT = Path('<workspace>/src/avd-issue41')
ART = Path('<workspace>/release-readiness-20260916')
DEST = ROOT / 'docs/resource-churn-2026-09-16'
ACCEPTED = ['final-normal-1000', 'final-early-1000', 'final-soak']
CALIBRATION = ['normal-smoke', 'normal-fixed-smoke', 'early-smoke',
               'normal-1000', 'early-1000', 'allocator-diagnostic']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def records(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode().strip()


def guard(name, allow_client_error=False):
    rows = records(ART / (name + '-guard.jsonl'))
    end = rows[-1]
    assert end['event'] == 'final' and end['status'] in (('ok','child-error') if allow_client_error else ('ok',))
    assert (allow_client_error or end['returncode'] == 0) and end['idle'] and not end['holders']
    assert not end['timed_out'] and not end['wedged'] and not end['abort_reason']
    return rows


def audit_run(name, manifest):
    rows = records(ART / (name + '.jsonl'))
    meta, end = rows[0], rows[-1]
    assert meta['type'] == 'metadata' and end['type'] == 'summary' and end['passed']
    assert meta['inputs_sha256'] == sha((ART / 'final-media/inputs.json').read_bytes())
    samples = [r for r in rows if r['type'] == 'sample']
    initial = next(r for r in rows if r['type'] == 'initial')
    assert len(samples) == end['cycles'] + 1
    assert [s['cycle'] for s in samples] == list(range(end['cycles'] + 1))
    assert len({(s['pid'], s['process_start_time']) for s in samples + [initial]}) == 1
    for metric in ['fd_count', 'dmabuf_references', 'dmabuf_objects', 'dmabuf_bytes']:
        assert all(s[metric] == initial[metric] for s in samples)
    # These final runs are stronger than the allowed bounds: all mapping and
    # RSS values must actually remain flat. Fail this report if that changes.
    for metric in ['map_count', 'mapped_bytes', 'vmrss_kib']:
        assert len({s[metric] for s in samples}) == 1, (name, metric)
    assert max(s['allocator']['allocated'] + s['allocator']['mmap'] for s in samples) \
        - (samples[0]['allocator']['allocated'] + samples[0]['allocator']['mmap']) <= 65536
    span = (samples[-1]['monotonic_ns'] - samples[0]['monotonic_ns']) / 1e9
    assert span == end['sample_span_seconds']
    assert end['cycles'] >= 1000
    if name == 'final-soak':
        assert span >= 3600 and meta['requested_seconds'] == 3600
    # Re-read the recorded workload independently of the live runner. Each
    # result must carry the exact independent software frame sequence/digest.
    count, pending, held = 0, [], 0
    for line in (ART / (name + '.workload.log')).read_text().splitlines():
        if line.startswith('frame '):
            pending.append(line)
        elif line.startswith('RESULT '):
            m = re.fullmatch(r'RESULT cycle=(\d+) stream=(\d+) pass=(\d+) frames=(\d+) MD5=([0-9a-f]{32})', line)
            assert m
            cy, stream, part, frames = map(int, m.groups()[:4])
            assert (cy, stream, part) == (count // 2 + 1, count // 2 % 4, count % 2)
            ref = manifest['inputs'][stream]
            assert pending == ref['frames'] and frames == len(pending) == 24
            assert m[5] == ref['md5']
            count += 1
            pending = []
        elif line.startswith('HELD_IMAGE_PASS '):
            held += 1
            assert line == 'HELD_IMAGE_PASS cycle=%d' % held
    assert not pending and count == (end['cycles'] + 20) * 2
    assert count * 24 == end['decoded_frames'] and held == end['held_image_checks']
    errors = (ART / (name + '.stderr.log')).read_text().splitlines()
    assert not any('Failed to destroy' in line or 'EARLY_EXPORT_FAIL' in line for line in errors)
    early = sum(line.startswith('EARLY_EXPORT_PASS:') for line in errors)
    assert early == (count * 24 if meta['mode'] == 'early' else 0)
    return {'metadata': meta, 'summary': end, 'initial_display': initial,
            'checkpoints': [s for s in samples if s['cycle'] in (0, 100, 500, 1000, end['cycles'])],
            'guard': guard(name), 'raw_replay': {'matched_frame_records': count * 24,
            'held_image_records': held, 'early_export_identity_records': early},
            'allocator_plateau_windows': [
                {'cycle_from': a, 'cycle_to': b,
                 'allocated_min': min(s['allocator']['allocated'] for s in samples[a:b+1]),
                 'allocated_max': max(s['allocator']['allocated'] for s in samples[a:b+1])}
                for a, b in [(0,100),(100,500),(500,1000),(1000,end['cycles'])]]}


def main():
    partial = '--partial' in sys.argv
    manifest = json.loads((ART / 'final-media/inputs.json').read_text())
    for item in manifest['inputs']:
        assert sha((ART / 'final-media' / item['name']).read_bytes()) == item['sha256']
    results = {n: audit_run(n, manifest) for n in ACCEPTED if not partial or n != 'final-soak'}
    interruption = {}
    for name in (['interrupted'] if partial else ['interrupted', 'interrupted-v2']):
        data = records(ART / (name + '.jsonl'))
        assert data[-1]['type'] == 'summary' and data[-1]['passed'] is False
        interruption[name] = {'summary': data[-1], 'guard': guard(name),
                              'log': (ART / (name + '.log')).read_text()}
    if not partial:
        recovery = records(ART / 'post-interrupt-v2.jsonl')[-1]
        assert recovery['passed'] and recovery['cycles'] == 4
        interruption['post-interrupt-v2'] = {'summary': recovery, 'guard': guard('post-interrupt-v2')}
    suites = {}
    for path in sorted((ART / 'final-codec-suites').glob('*-comparison.json')):
        if 'strict-comparison' in path.name:
            continue
        row = json.loads(path.read_text())
        assert not row['lost'] and not row['gained']
        suites[row['suite']] = row
    if not partial:
        assert len(suites) == 6
        suite_guard = guard('final-codec-suites')
        assert 'ALL EXACT PASS SETS MATCH' in (ART / 'final-codec-suites.log').read_text()
    else:
        suite_guard = 'NOT RUN: queued after successful soak; selected O3 build differs from previous O2 codec qualification.'
    source_tree = git('rev-parse', 'HEAD:src')
    assert source_tree == git('rev-parse', 'e515385240bff10378f78c03dd7cfafed54786aa:src')
    report = {
        'issue': 'https://github.com/iconidentify/libva-v4l2_request/issues/41',
        'pr': 'https://github.com/iconidentify/libva-v4l2_request/pull/71',
        'date': '2026-09-16',
        'issue_complete': False,
        'hardware_campaign_complete': not partial,
        'remaining': ['Fresh uninterrupted 60-minute soak', 'Exact selected-build codec comparison',
                      'Updated interruption-wrapper hardware check', 'Merge'] if partial else ['Merge'],
        'code_head': git('rev-parse', 'HEAD'), 'production_src_tree': source_tree,
        'production_source_changed': False,
        'review': 'Maintainer implementation and self-review; not an independent review.',
        'machine': json.loads((ART / 'hardware-identity.json').read_text()),
        'driver_builds': json.loads((ART / 'driver-build-comparison.json').read_text()),
        'hardware_code_equivalence': json.loads((ART / 'hardware-code-equivalence.json').read_text()),
        'code_head_ci': json.loads((ART / 'ci-code-head.json').read_text()),
        'inputs': manifest, 'acceptance_campaigns': results,
        'interrupted_client': interruption,
        'exact_codec_pass_sets': suites, 'codec_guard': suite_guard,
        'historical_fault_boundary': {
            'journal_since': '2026-09-16 10:53:48 -0700',
            'reason': 'Known Sep 15 faults remain in the boot journal. This boundary begins the earlier successful #35 qualification; its guards ended idle at 10:54:04 and 10:57:47 PDT. No later fault was found; no module reload/reset was used to bypass preflight.'},
        'offline': {'asan_ubsan': {'passed': 128, 'failed': 0},
                    'software_frame_check': 'native-size/resolution/crop match; truncation rejected',
                    'software_shared_contexts': {'streams': 4, 'frames': 168},
                    'wrapper_stop_regression': 'Old wrapper fails; responsive and SIGTERM-ignoring coordinator fixtures pass after fix.'},
        'calibration': {n: {'metadata': records(ART/(n+'.jsonl'))[0],
                           'summary': records(ART/(n+'.jsonl'))[-1],
                           'guard': guard(n, allow_client_error=True)} for n in CALIBRATION},
        'limits_and_not_run': [
            'Fixed synthetic 640x360 workload, 24 frames per clip; normal and early-export lifecycles each decode/drain and seek/flush/redecode.',
            'FD/dma-buf return to initial-display state; mapping and RSS comparisons begin after 20 warmup lifecycles. One initialized VA display survives all measured cycles.',
            'All accepted final mapping/RSS curves are flat. Declared 4 MiB allocator-arena/mapped/RSS allowances and 64 KiB allocation allowance are workload-specific, not universal.',
            'The failed early-export calibration at cycle 909 lacks allocator telemetry; its 2 MiB increase remains unexplained and failed. Later final runs are fresh evidence, not a reclassification.',
            'The first smoke leaked a client-owned surface because its FFmpeg pool was freed before its derived image. Corrected fixture ordering; no production driver leak claimed.',
            'Calibration source_commit fields identify their base checkouts; some fixture/allocator edits were uncommitted. Their manifests retain actual workload source/binary hashes. They are not final acceptance runs.',
            'Selected on-disk kernel module identity is recorded; actual loaded module binary identity is unavailable.',
            'dma-buf none-observed means no process descriptors at quiescent checkpoints; global kernel allocations and unsampled descendants are not measured.',
            'No browser rendering, concurrent API calls, other resolutions, suspend/reboot, installation or new codec support is qualified.',
            'Prior known codec failures remain failures; exact pass sets are compared without removing their raw full-suite denominators.',
            'The exact selected O3 binary codec comparison is not run yet.' if partial else
            'Selected full-codec summary/result records are included in the archive; full per-vector stderr remains local.']}
    if partial:
        data = records(ART/'final-soak.jsonl')
        assert data[-1]['passed'] is False
        samples = [r for r in data if r['type']=='sample']
        report['aborted_soak'] = {'metadata': data[0], 'summary': data[-1],
            'sample_span_seconds': (samples[-1]['monotonic_ns']-samples[0]['monotonic_ns'])/1e9,
            'first': samples[0], 'last': samples[-1],
            'guard': records(ART/'final-soak-guard.jsonl'),
            'later_idle_preflight': guard('post-foreign-idle') if (ART/'post-foreign-idle-guard.jsonl').exists()
                else records(ART/'post-foreign-idle.jsonl')}
    # Only task-owned generated media and declared logs enter the archive.
    names = set()
    for n in ACCEPTED + CALIBRATION + ['interrupted', 'interrupted-v2', 'post-interrupt-v2']:
        names.update(p.name for p in ART.glob(n + '*') if p.is_file() and p.suffix in ('.jsonl','.log'))
    names.update(['hardware-identity.json', 'driver-build-comparison.json', 'hardware-final.sh',
                  'hardware-code-equivalence.json', 'ci-code-head.json',
                  'post-soak.sh', 'final-codec-suites.py', 'final-codec-suites.log',
                  'final-codec-suites-guard.jsonl', 'final-offline-v2.log',
                  'interrupt-wrapper-before.log', 'interrupt-wrapper-fix.log', 'make-evidence.py'])
    for directory in ['media', 'allocator-media', 'final-media']:
        names.update(str(p.relative_to(ART)) for p in (ART/directory).iterdir()
                     if p.suffix in ('.json','.mkv','.webm','.reference'))
    names.update(str(p.relative_to(ART)) for p in (ART/'final-codec-suites').rglob('*')
                 if p.is_file() and (p.name in ('summary.json','results.jsonl') or p.name.endswith('-comparison.json')))
    names = {n for n in names if (ART/n).is_file()}
    if partial:
        names.add('post-foreign-idle.jsonl')
    # Strip only the owner's workspace prefix in public text. Record both raw
    # and public hashes so this sanitization does not masquerade as raw bytes.
    DEST.mkdir(exist_ok=True)
    archive = DEST/'raw-evidence.tar.xz'
    member_hashes = {}
    with tarfile.open(archive, 'w:xz', preset=6) as tar:
        for name in sorted(names):
            raw = (ART/name).read_bytes()
            data = raw if Path(name).suffix in ('.mkv','.webm') else raw.replace(b'<workspace>', b'<workspace>')
            member_hashes[name] = {'raw_sha256': sha(raw), 'public_sha256': sha(data), 'size': len(data)}
            info = tarfile.TarInfo(name)
            info.size, info.mtime, info.mode = len(data), 1789588800, 0o644
            tar.addfile(info, io.BytesIO(data))
    report['archive'] = {'path': 'resource-churn-2026-09-16/raw-evidence.tar.xz',
                         'sha256': sha(archive.read_bytes()), 'members': member_hashes,
                         'sanitization': 'Only <workspace> workspace prefix replaced with <workspace> in public text; original and transformed hashes retained.'}
    report['source_hashes'] = {name: sha((ROOT/name).read_bytes()) for name in
        ['tests/resource-workload.c','tests/resource-campaign.py','tests/resource-interrupt.py',
         'tests/resource-campaign-check.py','tests/resource-churn.py','tests/frame-check.c','tests/early-export.c']}
    text = json.dumps(report, indent=2).replace('<workspace>', '<workspace>')+'\n'
    (ROOT/'docs/resource-churn-validation-2026-09-16.json').write_text(text)
    print(json.dumps({'archive_bytes': archive.stat().st_size, 'members': len(names),
                      'accepted_cycles': {k:v['summary']['cycles'] for k,v in results.items()}},indent=2))


if __name__ == '__main__':
    main()
