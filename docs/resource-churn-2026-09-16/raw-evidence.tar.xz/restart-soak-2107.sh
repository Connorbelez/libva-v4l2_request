#!/bin/bash
set -euo pipefail
cd <workspace>/src/avd-issue41-soak
export LIBVA_DRIVERS_PATH=<workspace>/src/avd-issue41/build-hardware/src
export LIBVA_DRIVER_NAME=v4l2_request
export V4L2R_SOURCE_COMMIT=0758361796905981d8855988f71f4c2ca5a66ff4
campaign=<workspace>/release-readiness-20260916
python3 tests/hwguard.py --identity avd --journal-since '2026-09-16 10:53:48 -0700' \
 --deadline 3900 --log "$campaign/soak-retry-2107-guard.jsonl" -- \
 python3 tests/resource-campaign.py run --mode early --cycles 1000000 --seconds 3600 \
 --max-mapped-growth-kib 4096 --directory "$campaign/final-media" \
 --output "$campaign/soak-retry-2107.jsonl" > "$campaign/soak-retry-2107.log" 2>&1
