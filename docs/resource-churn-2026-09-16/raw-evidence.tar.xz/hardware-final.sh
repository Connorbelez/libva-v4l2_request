#!/bin/bash
set -euo pipefail
cd <workspace>/src/avd-issue41
export LIBVA_DRIVERS_PATH=$PWD/build-hardware/src
export LIBVA_DRIVER_NAME=v4l2_request
export V4L2R_SOURCE_COMMIT=6ac9a4f351d7b94ac6b1f53f3acf0f4db52b7ea8
campaign=<workspace>/release-readiness-20260916
python3 tests/hwguard.py --identity avd --journal-since '2026-09-16 10:53:48 -0700' \
    --deadline 60 --log "$campaign/interrupted-guard.jsonl" -- \
    python3 tests/resource-interrupt.py --directory "$campaign/final-media" \
    --output "$campaign/interrupted.jsonl" >"$campaign/interrupted.log" 2>&1
for mode in normal early; do
    python3 tests/hwguard.py --identity avd --journal-since '2026-09-16 10:53:48 -0700' \
        --deadline 600 --log "$campaign/final-$mode-1000-guard.jsonl" -- \
        python3 tests/resource-campaign.py run --mode "$mode" --cycles 1000 \
        --max-mapped-growth-kib 4096 --directory "$campaign/final-media" \
        --output "$campaign/final-$mode-1000.jsonl" >"$campaign/final-$mode-1000.log" 2>&1
done
python3 tests/hwguard.py --identity avd --journal-since '2026-09-16 10:53:48 -0700' \
    --deadline 3900 --log "$campaign/final-soak-guard.jsonl" -- \
    python3 tests/resource-campaign.py run --mode early --cycles 1000000 --seconds 3600 \
    --max-mapped-growth-kib 4096 --directory "$campaign/final-media" \
    --output "$campaign/final-soak.jsonl" >"$campaign/final-soak.log" 2>&1
