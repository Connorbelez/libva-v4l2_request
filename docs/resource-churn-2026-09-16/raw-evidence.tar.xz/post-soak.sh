#!/bin/bash
set -euo pipefail
cd <workspace>/src/avd-issue41
campaign=<workspace>/release-readiness-20260916
python3 - <<'CHECK'
import json
from pathlib import Path
p=Path('<workspace>/release-readiness-20260916')
s=json.loads((p/'final-soak.jsonl').read_text().splitlines()[-1])
g=json.loads((p/'final-soak-guard.jsonl').read_text().splitlines()[-1])
assert s.get('passed') and s['sample_span_seconds'] >= 3600
assert g.get('event') == 'final' and g['status']=='ok' and g['idle']
CHECK
export LIBVA_DRIVERS_PATH=$PWD/build-hardware/src
export LIBVA_DRIVER_NAME=v4l2_request
export V4L2R_SOURCE_COMMIT=$(git rev-parse HEAD)
python3 tests/hwguard.py --identity avd --journal-since '2026-09-16 10:53:48 -0700' \
  --deadline 900 --log "$campaign/final-codec-suites-guard.jsonl" -- \
  python3 "$campaign/final-codec-suites.py" > "$campaign/final-codec-suites.log" 2>&1
python3 tests/hwguard.py --identity avd --journal-since '2026-09-16 10:53:48 -0700' \
  --deadline 60 --log "$campaign/interrupted-v2-guard.jsonl" -- \
  python3 tests/resource-interrupt.py --directory "$campaign/final-media" \
  --output "$campaign/interrupted-v2.jsonl" > "$campaign/interrupted-v2.log" 2>&1
python3 tests/hwguard.py --identity avd --journal-since '2026-09-16 10:53:48 -0700' \
  --deadline 60 --log "$campaign/post-interrupt-v2-guard.jsonl" -- \
  python3 tests/resource-campaign.py run --mode normal --cycles 4 \
  --directory "$campaign/final-media" --output "$campaign/post-interrupt-v2.jsonl" > "$campaign/post-interrupt-v2.log" 2>&1
