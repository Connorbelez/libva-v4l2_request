import json, os, subprocess
from pathlib import Path
root=Path('<workspace>/src/avd-issue41-soak')
driver=Path('<workspace>/src/avd-issue41/build-hardware/src')
out=Path('<workspace>/release-readiness-20260916/final-codec-suites')
out.mkdir(exist_ok=True)
fluster=Path('<workspace>/src/fluster')
base=json.loads((root/'docs/r11-pass-sets.json').read_text())['suites']
items=[('hevc','h.265/JCT-VC-HEVC_V1.json'),('avc','h.264/JVT-AVC_V1.json'),('frext','h.264/JVT-FR-EXT.json'),('vp9','vp9/VP9-TEST-VECTORS.json'),('vp9-high10','vp9/VP9-TEST-VECTORS-HIGH.json'),('overrides','h.264/JVT-AVC_V1.json')]
# Resolve the exact keys from the versioned record, rather than infer pass names.
print('baseline keys:',list(base),flush=True)
for key,suite in items:
 if (out/key).exists():
  raise SystemExit('refusing to overwrite an existing suite directory: '+key)
 if key not in base:
  aliases={'avc':'h264','frext':'h264_high10'}
  key=aliases.get(key,key)
 assert key in base,key
 env=dict(os.environ,LIBVA_V4L2_DIAG='json')
 mode=base[key]['high10']
 if mode!='off':env['LIBVA_V4L2_H264_HIGH10']=mode
 else:env.pop('LIBVA_V4L2_H264_HIGH10',None)
 cmd=['python3','tests/conformance.py',str(fluster/'test_suites'/suite),str(fluster/'resources'),'--driver',str(driver),'--output',str(out/key),'--timeout','45']
 if key in ('vp9-high10','overrides'):
  cmd += ['--vectors',*base[key]['passing_vectors']]
 if base[key]['profile_mismatch']:cmd.append('--profile-mismatch')
 print('START',key,flush=True)
 result=subprocess.run(cmd,cwd=root,env=env)
 if result.returncode not in (0,1):raise SystemExit(result.returncode)
 summary=json.loads((out/key/'summary.json').read_text())
 assert summary['complete'],summary
 records=[json.loads(s) for s in (out/key/'results.jsonl').read_text().splitlines()]
 actual={v['vector'] for v in records if v.get('event')=='result' and v['success']}
 expected=set(base[key]['passing_vectors'])
 diff={'suite':key,'passed':len(actual),'total':base[key]['total'],'lost':sorted(expected-actual),'gained':sorted(actual-expected)}
 (out/f'{key}-comparison.json').write_text(json.dumps(diff,indent=2)+'\n')
 print('COMPARE',json.dumps(diff),flush=True)
 if key in ('hevc','avc','frext','vp9'):
  with (out/f'{key}-strict-comparison.json').open('w') as report:
   subprocess.run(['python3','tests/compare-results.py','--baseline','docs/r11-pass-sets.json','--candidate',str(out/key/'summary.json'),'--suite',key],cwd=root,stdout=report,check=False)
 if actual!=expected:raise SystemExit(3)
print('ALL EXACT PASS SETS MATCH',flush=True)
